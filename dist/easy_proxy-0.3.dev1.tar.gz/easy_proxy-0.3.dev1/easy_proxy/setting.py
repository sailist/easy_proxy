import importlib

TIME_OUT = 10
spyder_list = []

IP = "localhost"
HOST = 9999

THREAD_NUM = {
    "check":7,
    "crawl":1,
    "route":1
}
